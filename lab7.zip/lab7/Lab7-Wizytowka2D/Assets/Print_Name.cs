﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Print_Name : MonoBehaviour
{

    public int ilosc = 5;
    private string DoWysw = "Adrian Mastalerz";
    // Start is called before the first frame update
    void Start()
    {
        if (ilosc < 1)
        {
            ilosc = 1;
            print("zmieniono na jeden");
        }

        for (int i=0; i<ilosc; i++)
        {
            print(DoWysw);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
